import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { getToken } from "firebase/messaging";
import { messaging } from "../firebase";
import axiosInstance from "../utils/axios";

function Login({ setIsLoggedIn }) {
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [serverError, setServerError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const vapidKey =
    "BCI-Cu-Pg0FnXdyxDeR6LHozhMO_5Ft5I5VIi7bI8ofJhOrHMffJgNbPnHczr1Rtlu9rqVKalQRkQJ5pC6qsc6c";

  const registerFcmToken = async (authToken) => {
    try {
      const currentToken = await getToken(messaging, { vapidKey });
      if (currentToken) {
        await axiosInstance.post(
          "/save-token",
          { token: currentToken },
          { headers: { Authorization: `Bearer ${authToken}` } }
        );
        console.log("FCM token registered:", currentToken);
      }
    } catch (error) {
      console.error("Error registering FCM token:", error);
    }
  };

  const validateForm = async (e) => {
    e.preventDefault();
    setServerError("");

    const email = e.target.email.value.trim();
    const password = e.target.password.value.trim();

    let valid = true;

    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      setEmailError("Enter a valid email address");
      valid = false;
    } else setEmailError("");

    if (!password || password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
      valid = false;
    } else setPasswordError("");

    if (!valid) return;

    try {
      setLoading(true);
      const response = await axiosInstance.post("/auth/admin/login", {
        email,
        password,
      });
      const authToken = response.data.token;
      localStorage.setItem("authToken", authToken);
      navigate("/");
      await registerFcmToken(authToken);
      setIsLoggedIn(true);
    } catch (err) {
      const message =
        err.response?.data?.message || "Login failed. Please try again.";
      setServerError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="min-h-screen flex items-center justify-center">
      <div className="w-full max-w-lg p-10 rounded-2xl shadow-2xl bg-gradient-to-b from-slate-400 via-white to-white backdrop-blur-lg">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-gray-800">
            Welcome Back!
          </h1>
          <p className="text-sm text-gray-800 mt-2">
            Sign in to access your dashboard
          </p>
        </div>

        <form className="space-y-6 mt-8" onSubmit={validateForm} noValidate>
          {/* Email */}
          <div>
            <label
              htmlFor="email"
              className="block text-sm font-medium text-gray-800"
            >
              Email address
            </label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="you@example.com"
              className={`mt-1 w-full px-4 py-3 rounded-lg bg-gray-100 text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-pink-400 ${
                emailError ? "border border-red-400" : "border border-gray-200"
              }`}
              required
            />
            {emailError && (
              <p className="text-sm text-red-500 mt-1">{emailError}</p>
            )}
          </div>

          {/* Password */}
          <div>
            <label
              htmlFor="password"
              className="block text-sm font-medium text-gray-800"
            >
              Password
            </label>
            <div className="relative">
              <input
                type={passwordVisible ? "text" : "password"}
                id="password"
                name="password"
                placeholder="••••••••"
                className={`mt-1 w-full px-4 py-3 pr-12 rounded-lg bg-gray-100 text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-pink-400 ${
                  passwordError
                    ? "border border-red-400"
                    : "border border-gray-200"
                }`}
                required
              />
              <button
                type="button"
                onClick={() => setPasswordVisible((prev) => !prev)}
                aria-label={passwordVisible ? "Hide password" : "Show password"}
                className="absolute top-1/2 right-4 transform -translate-y-1/2 text-sm text-gray-600 hover:text-gray-800"
              >
                {passwordVisible ? "Hide" : "Show"}
              </button>
            </div>
            {passwordError && (
              <p className="text-sm text-red-500 mt-1">{passwordError}</p>
            )}
          </div>

          {/* Server Error */}
          {serverError && (
            <p className="text-center text-sm text-red-600">{serverError}</p>
          )}

          {/* Forgot password */}
          <div className="flex justify-end text-sm">
            <Link
              to="/forgot-password"
              className="text-gray-800 hover:text-gray-900 underline"
            >
              Forgot password?
            </Link>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-slate-400 to-zinc-300 hover:opacity-90 text-gray-800 font-semibold rounded-lg transition duration-200 shadow-lg flex items-center justify-center"
          >
            {loading ? (
              <span className="loader border-2 border-gray-800 border-t-transparent rounded-full w-5 h-5 animate-spin"></span>
            ) : (
              "Sign In"
            )}
          </button>
        </form>
      </div>
    </section>
  );
}

export default Login;



// "use client"

// import { useState } from "react"
// import { Link, useNavigate } from "react-router-dom"
// import { getToken } from "firebase/messaging"
// import { messaging } from "../firebase"
// import axiosInstance from "../utils/axios"

// function Login({ setIsLoggedIn }) {
//   const [step, setStep] = useState("email")
//   const [email, setEmail] = useState("")
//   const [otp, setOtp] = useState("")
//   const [password, setPassword] = useState("")
//   const [passwordVisible, setPasswordVisible] = useState(false)
//   const [emailError, setEmailError] = useState("")
//   const [otpError, setOtpError] = useState("")
//   const [passwordError, setPasswordError] = useState("")
//   const [serverError, setServerError] = useState("")
//   const [loading, setLoading] = useState(false)
//   const navigate = useNavigate()
//   const vapidKey = "BCI-Cu-Pg0FnXdyxDeR6LHozhMO_5Ft5I5VIi7bI8ofJhOrHMffJgNbPnHczr1Rtlu9rqVKalQRkQJ5pC6qsc6c"

//   const registerFcmToken = async (authToken) => {
//     try {
//       const currentToken = await getToken(messaging, { vapidKey })
//       if (currentToken) {
//         await axiosInstance.post(
//           "/save-token",
//           { token: currentToken },
//           { headers: { Authorization: `Bearer ${authToken}` } },
//         )
//         console.log("FCM token registered:", currentToken)
//       }
//     } catch (error) {
//       console.error("Error registering FCM token:", error)
//     }
//   }

//   const handleSendOtp = async (e) => {
//     e.preventDefault()
//     setServerError("")
//     setEmailError("")

//     if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
//       setEmailError("Enter a valid email address")
//       return
//     }

//     try {
//       setLoading(true)
//       await axiosInstance.post("/auth/admin/send-login-otp", { email })
//       setStep("otp")
//     } catch (err) {
//       const message = err.response?.data?.message || "Failed to send OTP. Please try again."
//       setServerError(message)
//     } finally {
//       setLoading(false)
//     }
//   }

//   const handleVerifyOtp = async (e) => {
//     e.preventDefault()
//     setServerError("")
//     setOtpError("")
//     setPasswordError("")

//     let valid = true

//     if (!otp || otp.length !== 6) {
//       setOtpError("OTP must be 6 digits")
//       valid = false
//     }
//     if (!password || password.length < 6) {
//       setPasswordError("Password must be at least 6 characters")
//       valid = false
//     }
//     if (!valid) return

//     try {
//       setLoading(true)
//       const response = await axiosInstance.post("/auth/admin/verify-login-otp", {
//         email,
//         otp,
//         password,
//       })

//       const authToken = response.data.token
//       localStorage.setItem("authToken", authToken)
//       await registerFcmToken(authToken)
//       setIsLoggedIn(true)
//       navigate("/")
//     } catch (err) {
//       const message = err.response?.data?.message || "Login failed. Please try again."
//       setServerError(message)
//     } finally {
//       setLoading(false)
//     }
//   }

//   const handleBackToEmail = () => {
//     setStep("email")
//     setOtp("")
//     setPassword("")
//     setOtpError("")
//     setPasswordError("")
//     setServerError("")
//   }

//   return (
//     <div className="min-h-screen w-full bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
//       <div className="w-full max-w-md">
//         <div className="bg-white rounded-2xl shadow-lg border border-slate-200 p-8">
//           {/* Header */}
//           <div className="mb-8">
//             <h1 className="text-3xl font-bold text-slate-900 mb-2">Welcome Back!</h1>
//             <p className="text-slate-600 text-sm">Sign in to access your dashboard</p>
//           </div>

//           {/* Step 1: Email */}
//           {step === "email" && (
//             <form className="space-y-5" onSubmit={handleSendOtp} noValidate>
//               <div>
//                 <label htmlFor="email" className="block text-sm font-semibold text-slate-700 mb-2">
//                   Email Address
//                 </label>
//                 <input
//                   type="email"
//                   id="email"
//                   value={email}
//                   onChange={(e) => setEmail(e.target.value)}
//                   placeholder="you@example.com"
//                   className={`w-full px-4 py-3 rounded-lg border-2 transition-colors bg-white text-slate-900 placeholder-slate-400 focus:outline-none ${
//                     emailError ? "border-red-500 focus:border-red-600" : "border-slate-200 focus:border-blue-500"
//                   }`}
//                   required
//                 />
//                 {emailError && <p className="text-red-600 text-sm mt-2 font-medium">{emailError}</p>}
//               </div>

//               {serverError && (
//                 <div className="bg-red-50 border border-red-200 rounded-lg p-3">
//                   <p className="text-red-700 text-sm font-medium">{serverError}</p>
//                 </div>
//               )}

//               <button
//                 type="submit"
//                 disabled={loading}
//                 className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white font-semibold rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
//               >
//                 {loading ? (
//                   <>
//                     <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
//                     Sending...
//                   </>
//                 ) : (
//                   "Send OTP"
//                 )}
//               </button>

//               <div className="text-center">
//                 <Link to="/forgot-password" className="text-blue-600 hover:text-blue-700 text-sm font-medium">
//                   Forgot password?
//                 </Link>
//               </div>
//             </form>
//           )}

//           {/* Step 2: OTP & Password */}
//           {step === "otp" && (
//             <form className="space-y-5" onSubmit={handleVerifyOtp} noValidate>
//               <div>
//                 <label htmlFor="otp" className="block text-sm font-semibold text-slate-700 mb-2">
//                   One-Time Password
//                 </label>
//                 <input
//                   type="text"
//                   id="otp"
//                   value={otp}
//                   onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
//                   placeholder="000000"
//                   maxLength={6}
//                   className={`w-full px-4 py-3 rounded-lg border-2 transition-colors bg-white text-slate-900 placeholder-slate-400 focus:outline-none text-center text-2xl tracking-widest font-mono ${
//                     otpError ? "border-red-500 focus:border-red-600" : "border-slate-200 focus:border-blue-500"
//                   }`}
//                   required
//                 />
//                 {otpError && <p className="text-red-600 text-sm mt-2 font-medium">{otpError}</p>}
//               </div>

//               <div>
//                 <label htmlFor="password" className="block text-sm font-semibold text-slate-700 mb-2">
//                   Password
//                 </label>
//                 <div className="relative">
//                   <input
//                     type={passwordVisible ? "text" : "password"}
//                     id="password"
//                     value={password}
//                     onChange={(e) => setPassword(e.target.value)}
//                     placeholder="••••••••"
//                     className={`w-full px-4 py-3 pr-12 rounded-lg border-2 transition-colors bg-white text-slate-900 placeholder-slate-400 focus:outline-none ${
//                       passwordError ? "border-red-500 focus:border-red-600" : "border-slate-200 focus:border-blue-500"
//                     }`}
//                     required
//                   />
//                   <button
//                     type="button"
//                     onClick={() => setPasswordVisible((prev) => !prev)}
//                     className="absolute top-1/2 right-4 transform -translate-y-1/2 text-slate-600 hover:text-slate-900 text-sm font-medium"
//                   >
//                     {passwordVisible ? "Hide" : "Show"}
//                   </button>
//                 </div>
//                 {passwordError && <p className="text-red-600 text-sm mt-2 font-medium">{passwordError}</p>}
//               </div>

//               {serverError && (
//                 <div className="bg-red-50 border border-red-200 rounded-lg p-3">
//                   <p className="text-red-700 text-sm font-medium">{serverError}</p>
//                 </div>
//               )}

//               <button
//                 type="submit"
//                 disabled={loading}
//                 className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white font-semibold rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
//               >
//                 {loading ? (
//                   <>
//                     <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
//                     Logging in...
//                   </>
//                 ) : (
//                   "Login"
//                 )}
//               </button>

//               <button
//                 type="button"
//                 onClick={handleBackToEmail}
//                 className="w-full py-2 text-slate-700 hover:text-slate-900 font-medium text-sm border border-slate-300 rounded-lg transition-colors hover:bg-slate-50"
//               >
//                 Back
//               </button>
//             </form>
//           )}
//         </div>

//         {/* Footer */}
//         <p className="text-center text-slate-600 text-sm mt-6">
//           Don't have an account?{" "}
//           <Link to="/signup" className="text-blue-600 hover:text-blue-700 font-semibold">
//             Sign up
//           </Link>
//         </p>
//       </div>
//     </div>
//   )
// }

// export default Login

